#include <fstream>

const int N = 10;

int mitad (int a[],int pinicial, int pfinal);
void ordenar (int a[],int pinicial, int pfinal);
void ingresar(int a[],int n);